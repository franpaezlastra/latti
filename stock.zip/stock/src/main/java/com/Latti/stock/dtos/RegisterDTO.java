package com.Latti.stock.dtos;

public record RegisterDTO(String username, String password) {
}
