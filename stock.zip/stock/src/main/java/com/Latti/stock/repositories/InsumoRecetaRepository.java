package com.Latti.stock.repositories;

import com.Latti.stock.modules.InsumoReceta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InsumoRecetaRepository extends JpaRepository<InsumoReceta, Long> {
}
