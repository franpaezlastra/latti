package com.Latti.stock.dtos;

public record InsumoCantidadDTO(
        Long insumoId,
        double cantidad
) {}
