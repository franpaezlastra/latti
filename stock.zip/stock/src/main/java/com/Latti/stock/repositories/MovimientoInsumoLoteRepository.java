package com.Latti.stock.repositories;


import com.Latti.stock.modules.MovimientoInsumoLote;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MovimientoInsumoLoteRepository extends JpaRepository<MovimientoInsumoLote, Long> {
}
