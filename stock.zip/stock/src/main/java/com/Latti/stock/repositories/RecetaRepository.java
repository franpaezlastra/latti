package com.Latti.stock.repositories;

import com.Latti.stock.modules.Receta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecetaRepository extends JpaRepository<Receta, Long> {
}
