    package com.Latti.stock.modules;

    public enum TipoMovimiento {
        ENTRADA,
        SALIDA
    }
