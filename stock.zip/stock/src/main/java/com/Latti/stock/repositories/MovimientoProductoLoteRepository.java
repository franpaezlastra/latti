package com.Latti.stock.repositories;

import com.Latti.stock.modules.MovimientoProductoLote;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MovimientoProductoLoteRepository extends JpaRepository<MovimientoProductoLote, Long> {
}