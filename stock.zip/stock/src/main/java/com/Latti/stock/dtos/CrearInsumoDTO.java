package com.Latti.stock.dtos;

import com.Latti.stock.modules.UnidadMedida;

public record CrearInsumoDTO(String nombre, UnidadMedida unidadMedida) {
}
