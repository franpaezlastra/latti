package com.Latti.stock.dtos;

public record LoginDTO(String username, String password) {
}
